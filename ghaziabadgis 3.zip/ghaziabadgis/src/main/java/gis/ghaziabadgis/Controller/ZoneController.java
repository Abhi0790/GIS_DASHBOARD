package gis.ghaziabadgis.Controller;

import gis.ghaziabadgis.Service.ZoneService;
import gis.ghaziabadgis.zoneDTO.ZoneDTO;
import org.locationtech.jts.io.WKTWriter;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/zones")
public class ZoneController {
    private final ZoneService zoneService;

    public ZoneController(ZoneService zoneService) {
        this.zoneService = zoneService;
    }

    @GetMapping("/alldata")
    public List<ZoneDTO> getAllZones() {
        WKTWriter writer = new WKTWriter();

        return zoneService.getAllZones().stream()
                .map(zone -> new ZoneDTO(
                        zone.getGid(),
                        zone.getId(),
                        zone.getZoneName(),
                        zone.getArea1(),
                        zone.getAreaSqKm(),
                        zone.getZoneNo(),
                        writer.write(zone.getGeom())
                ))
                .collect(Collectors.toList());
    }

    @GetMapping("/byZoneNo")
    public ZoneDTO getZoneByZoneNo(@RequestParam("zoneNo") String zoneNo) {
        WKTWriter writer = new WKTWriter();

        return zoneService.getZoneByZoneNo(zoneNo)
                .map(zone -> new ZoneDTO(
                        zone.getGid(),
                        zone.getId(),
                        zone.getZoneName(),
                        zone.getArea1(),
                        zone.getAreaSqKm(),
                        zone.getZoneNo(),
                        writer.write(zone.getGeom())
                ))
                .orElseThrow(() -> new RuntimeException("Zone not found with zoneNo: " + zoneNo));
    }

}

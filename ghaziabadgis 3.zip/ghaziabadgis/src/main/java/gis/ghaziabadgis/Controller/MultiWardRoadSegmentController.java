package gis.ghaziabadgis.Controller;

import gis.ghaziabadgis.Entity.MultiWardRoadSegment;
import gis.ghaziabadgis.Service.MultiWardRoadSegmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/multiwardroads")
@CrossOrigin("*")
public class MultiWardRoadSegmentController {

    private final MultiWardRoadSegmentService service;

    public MultiWardRoadSegmentController(MultiWardRoadSegmentService service) {
        this.service = service;
    }

    @GetMapping("/all")
    public List<MultiWardRoadSegment> getAll() {
        return service.getAll();
    }

    @GetMapping("/ward")
    public List<MultiWardRoadSegment> getByWard(@RequestParam String wardNo) {
        return service.getByWardNo(wardNo);
    }


    @GetMapping("/search")
    public List<MultiWardRoadSegment> getByRoad(@RequestParam String name) {
        return service.getByRoadName(name);
    }
}

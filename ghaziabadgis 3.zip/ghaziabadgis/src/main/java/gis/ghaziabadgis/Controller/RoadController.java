package gis.ghaziabadgis.Controller;

import gis.ghaziabadgis.Entity.Road;
import gis.ghaziabadgis.Entity.Ward;
import gis.ghaziabadgis.Service.RoadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/road")
public class RoadController {

    private final RoadService roadService;

    public RoadController(RoadService roadService) {
        this.roadService = roadService;
    }

    @GetMapping("/ward")
    public List<Road> getByWard(@RequestParam String wardNo) {
        System.out.println("Received wardNo: " + wardNo); // log
        return roadService.getByWardNo(wardNo);
    }

    @GetMapping("/zone")
    public List<Road> getByZone(@RequestParam String zoneNo) {
        return roadService.getByZoneNo(zoneNo);
    }

    @GetMapping("/ownership")
    public List<Road> getByOwnership(@RequestParam String ownership) {
        return roadService.getByOwnership(ownership);
    }

//    @GetMapping("/carriage")
//    public List<Road> getByCarriage(@RequestParam String carriage) {
//        return roadService.getByCarriage(carriage); }

    @GetMapping("/condition")
    public List<Road> getByCondition(@RequestParam String condition) {
        return roadService.getByCondition(condition);
    }
    @GetMapping("/countWards")
    public int countWardsByZone(@RequestParam String zoneNo) {
        return roadService.countWardsByZoneNo(zoneNo);
    }

    @GetMapping("/countRoads")
    public int countRoadsByWard(@RequestParam String wardNo) {
        return roadService.countRoadsByWardNo(wardNo);
    }

    @GetMapping("/allWardsByZoneNo")
    public List<Map<String, String>> getDistinctWards(@RequestParam String zoneNo) {
        return roadService.getDistinctWardsByZoneNo(zoneNo);
    }

    @GetMapping("/all")
    public List<Road> getAllRoads() {
        return roadService.getAllRoads();
    }
    @GetMapping("/multi-ward-roads")
    public ResponseEntity<List<Road>> getRoadsWithMultipleWards() {
        return ResponseEntity.ok(roadService.getRoadsWithMultipleWards());
    }


}

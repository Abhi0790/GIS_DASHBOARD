package gis.ghaziabadgis.Controller;


import gis.ghaziabadgis.Entity.Ward;
import gis.ghaziabadgis.Service.WardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ward")
@CrossOrigin(origins = "*")
public class WardController {

    @Autowired
    private WardService wardBoundaryService;

    @GetMapping("/all")
    public List<Ward> getAllWards() {
        return wardBoundaryService.getAllWards();
    }


    @GetMapping("/wardNo")
    public List<Ward> getByWardNo(@RequestParam String wardNo) {
        return wardBoundaryService.getByWardNo(wardNo);
    }
}


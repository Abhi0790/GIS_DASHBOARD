package gis.ghaziabadgis.ServiceIMPL;

import gis.ghaziabadgis.Entity.Road;
import gis.ghaziabadgis.Repo.RoadRepository;
import gis.ghaziabadgis.Service.RoadService;
import org.locationtech.jts.io.WKTWriter;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class RoadServiceImpl implements RoadService {

    private final RoadRepository roadRepository;

    public RoadServiceImpl(RoadRepository roadRepository) {
        this.roadRepository = roadRepository;
    }

    private List<Road> convertToWkt(List<Road> roads) {
        WKTWriter writer = new WKTWriter();
        return roads.stream()
                .map(road -> {
                    if (road.getGeom() != null) {
                        road.setWkt(writer.write(road.getGeom()));
                        road.setGeom(null);
                    }
                    return road;
                })
                .collect(Collectors.toList());
    }

    @Override
    public List<Road> getByWardNo(String wardNo) { // Changed to String
        return convertToWkt(roadRepository.findByWardNo(wardNo));
    }

    @Override
    public List<Road> getByZoneNo(String zoneNo) {
        return convertToWkt(roadRepository.findByZoneNo(zoneNo));
    }

    @Override
    public List<Road> getByOwnership(String ownership) {
        return convertToWkt(roadRepository.findByOwnership(ownership));
    }

    @Override
    public List<Road> getByCondition(String condition) {
        return convertToWkt(roadRepository.findByCondition(condition));
    }

    @Override
    public int countWardsByZoneNo(String zoneNo) {
        return roadRepository.countDistinctWardsByZoneNo(zoneNo);
    }

    @Override
    public int countRoadsByWardNo(String wardNo) {
        return roadRepository.countRoadsByWardNo(wardNo);
    }

    @Override
    public List<Road> getAllRoads() {
        return convertToWkt(roadRepository.findAll());
    }


    @Override
    public List<Map<String, String>> getDistinctWardsByZoneNo(String zoneNo) {
        List<Object[]> results = roadRepository.findDistinctWardsByZoneNo(zoneNo);

        return results.stream().map(obj -> {
            Map<String, String> ward = new HashMap<>();
            ward.put("wardNo", String.valueOf(obj[0]));
            ward.put("wardName", String.valueOf(obj[1]));
            return ward;
        }).collect(Collectors.toList());
    }

    @Override
    public List<Road> getRoadsWithMultipleWards() {
        return convertToWkt(roadRepository.findRoadsWithMultipleWards());
    }

}
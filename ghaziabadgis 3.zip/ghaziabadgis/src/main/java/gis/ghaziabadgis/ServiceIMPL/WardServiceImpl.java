package gis.ghaziabadgis.ServiceIMPL;

import gis.ghaziabadgis.Entity.Ward;
import gis.ghaziabadgis.Repo.WardRepository;
import gis.ghaziabadgis.Service.WardService;
import org.locationtech.jts.io.WKTWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WardServiceImpl implements WardService {

    @Autowired
    private WardRepository wardRepository;

    @Override
    public List<Ward> getAllWards() {
        return convertToWkt(wardRepository.findAll());
    }

    private List<Ward> convertToWkt(List<Ward> wards) {
        WKTWriter writer = new WKTWriter();
        return wards.stream()
                .map(ward -> {
                    if (ward.getGeom() != null) {
                        ward.setWkt(writer.write(ward.getGeom()));
                        ward.setGeom(null); // optional: don't return geometry object
                    }
                    return ward;
                })
                .collect(Collectors.toList());
    }

    @Override
    public List<Ward> getByWardNo(String wardNo) {
        return convertToWkt(wardRepository.findByWardNo(wardNo));
    }
}

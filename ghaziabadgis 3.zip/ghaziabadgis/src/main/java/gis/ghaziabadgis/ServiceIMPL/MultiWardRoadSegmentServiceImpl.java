package gis.ghaziabadgis.ServiceIMPL;

import gis.ghaziabadgis.Entity.MultiWardRoadSegment;
import gis.ghaziabadgis.Repo.MultiWardRoadSegmentRepository;
import gis.ghaziabadgis.Service.MultiWardRoadSegmentService;
import org.locationtech.jts.io.WKTWriter;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MultiWardRoadSegmentServiceImpl implements MultiWardRoadSegmentService {

    private final MultiWardRoadSegmentRepository repo;

    public MultiWardRoadSegmentServiceImpl(MultiWardRoadSegmentRepository repo) {
        this.repo = repo;
    }

    private List<MultiWardRoadSegment> convertToWKT(List<MultiWardRoadSegment> list) {
        WKTWriter writer = new WKTWriter();
        return list.stream()
                .map(r -> {
                    if (r.getGeom() != null) {
                        r.setWkt(writer.write(r.getGeom()));
                        r.setGeom(null); // exclude raw geometry in JSON
                    }
                    return r;
                }).collect(Collectors.toList());
    }

    @Override
    public List<MultiWardRoadSegment> getAll() {
        return convertToWKT(repo.findAll());
    }

    @Override
    public List<MultiWardRoadSegment> getByWardNo(String wardNo) {
        return convertToWKT(repo.findByClippedWardNo(wardNo));
    }

    @Override
    public List<MultiWardRoadSegment> getByRoadName(String name) {
        return convertToWKT(repo.findByRoadName(name));
    }
}

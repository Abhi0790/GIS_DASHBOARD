package gis.ghaziabadgis.zoneDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ZoneDTO {
    private int gid;
    private double id;
    private String zoneName;
    private double area1;
    private double areaSqKm;
    private String zoneNo;
    private String wkt;
}

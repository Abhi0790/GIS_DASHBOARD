package gis.ghaziabadgis.Entity;

import jakarta.persistence.*;
import org.locationtech.jts.geom.Geometry;

@Entity
@Table(name = "dummy_zone_boundary")
    public class Zone {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer gid;

    private Double id;

    @Column(name = "zone_name")
    private String zoneName;

    @Column(name = "area_1")
    private Double area1;

    @Column(name = "area_sq_km")
    private Double areaSqKm;

    @Column(name = "zone_no")
    private String zoneNo;

    @Column(columnDefinition = "geometry")
    private Geometry geom;

    private String wkt; // Geometry as WKT

    public Integer getGid() {
        return gid;
    }

    public void setGid(Integer gid) {
        this.gid = gid;
    }

    public Double getId() {
        return id;
    }

    public void setId(Double id) {
        this.id = id;
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public Double getArea1() {
        return area1;
    }

    public void setArea1(Double area1) {
        this.area1 = area1;
    }

    public Double getAreaSqKm() {
        return areaSqKm;
    }

    public void setAreaSqKm(Double areaSqKm) {
        this.areaSqKm = areaSqKm;
    }

    public String getZoneNo() {
        return zoneNo;
    }

    public void setZoneNo(String zoneNo) {
        this.zoneNo = zoneNo;
    }

    public Geometry getGeom() {
        return geom;
    }

    public void setGeom(Geometry geom) {
        this.geom = geom;
    }

    public String getWkt() {
        return wkt;
    }

    public void setWkt(String wkt) {
        this.wkt = wkt;
    }
}


package gis.ghaziabadgis.Entity;

import jakarta.persistence.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Formula;
import org.locationtech.jts.geom.Geometry;

@Entity
@Table(name = "dummy_ward_boundary")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Ward {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer gid;

    @Column(name = "id")
    private Double id;

    @Column(name = "id_1")
    private Double id1;

    @Column(name = "ward_name", length = 255)
    private String wardName;

    @Column(name = "ward_no", length = 50)
    private String wardNo;

    @Column(name = "ward_exten", length = 254)
    private String wardExten;

    @Column(length = 100)
    private String area;

    @Column(columnDefinition = "geometry")
    private Geometry geom;

    @Formula("ST_AsText(geom)")
    private String wkt; // Optional if you're planning to export geometry in WKT format
}

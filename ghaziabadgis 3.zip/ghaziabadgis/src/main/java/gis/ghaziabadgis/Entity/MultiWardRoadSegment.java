package gis.ghaziabadgis.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

@Entity
@Table(name = "multiward_roads")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MultiWardRoadSegment {

    @Id
    @Column(name = "original_road_gid")
    private Integer originalRoadGid;

    @Column(name = "ward_gid")
    private Integer wardGid;

    @Column(name = "gis_id")
    private Integer gisId;

    @Column(name = "zone_no")
    private String zoneNo;

    @Column(name = "zone_name")
    private String zoneName;

    @Column(name = "original_ward_no")
    private String originalWardNo;

    @Column(name = "original_ward_name")
    private String originalWardName;

    @Column(name = "clipped_ward_no")
    private String clippedWardNo;

    @Column(name = "clipped_ward_name")
    private String clippedWardName;

    private String ownership;

    @Column(name = "road_name")
    private String roadName;

    @Column(name = "row_meter")
    private Double rowMeter;

    private String rowcls;

    @Column(name = "carriage_w")
    private Double carriageW;

    @Column(name = "carriage_m")
    private String carriageM;

    @Column(name = "length_within_ward")
    private Double lengthWithinWard;

    @Column(name = "length_met")
    private Double lengthMet;

    private String condition;

    @Column(name = "year_of_co")
    private Integer yearOfCo;

    private String category;

    @Column(columnDefinition = "geometry")
    private Geometry geom;

    @Transient
    private String wkt;
}

package gis.ghaziabadgis.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

@Entity
@Table(name = "dummyq12")  // Updated table name as per your DB
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Road {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer gid;

    @Column(name = "gis_id")
    private Long gisId;

    @Column(name = "zone_no", length = 50)
    private String zoneNo;

    @Column(name = "zone_name", length = 100)
    private String zoneName;

    @Column(name = "ward_no", length = 50)
    private String wardNo;

    @Column(name = "ward_name", length = 100)
    private String wardName;

    @Column(length = 50)
    private String ownership;

    @Column(name = "road_name", length = 100)
    private String roadName;

    @Column(name = "row_meter_", columnDefinition = "numeric")
    private Double rowMeter;

    @Column(name = "rowcls", length = 100)
    private String rowCls;

    @Column(name = "carriage_w")
    private Double carriageW;

    @Column(name = "carriage_m", length = 50)
    private String carriageM;

    @Column(name = "length_met")
    private Double lengthMet;

    @Column(length = 50)
    private String condition;

    @Column(name = "year_of_co")
    private Integer yearOfCo; // This matches the numeric type in DB

    @Column(length = 20)
    private String category;

    @Column(columnDefinition = "geometry")
    private Geometry geom;

    @Transient
    private String wkt;
}

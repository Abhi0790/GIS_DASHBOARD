package gis.ghaziabadgis.Service;

import gis.ghaziabadgis.Entity.Road;

import java.util.List;
import java.util.Map;

public interface RoadService {

    List<Road> getByWardNo(String wardNo);

    List<Road> getByZoneNo(String zoneNo);

    List<Road> getByOwnership(String ownership);

    List<Road> getByCondition(String condition);

    int countWardsByZoneNo(String zoneNo);

    int countRoadsByWardNo(String wardNo);

    List<Road> getAllRoads();

    List<Map<String, String>> getDistinctWardsByZoneNo(String zoneNo);


    List<Road> getRoadsWithMultipleWards();



}

package gis.ghaziabadgis.Service;

import gis.ghaziabadgis.Entity.MultiWardRoadSegment;
import java.util.List;

public interface MultiWardRoadSegmentService {
    List<MultiWardRoadSegment> getAll();
    List<MultiWardRoadSegment> getByWardNo(String wardNo);
    List<MultiWardRoadSegment> getByRoadName(String name);
}

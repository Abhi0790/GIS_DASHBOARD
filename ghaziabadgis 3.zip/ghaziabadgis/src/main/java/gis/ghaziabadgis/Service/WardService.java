package gis.ghaziabadgis.Service;

import gis.ghaziabadgis.Entity.Ward;

import java.util.List;

public interface WardService {
    List<Ward> getAllWards();

    List<Ward> getByWardNo(String wardNo);
}

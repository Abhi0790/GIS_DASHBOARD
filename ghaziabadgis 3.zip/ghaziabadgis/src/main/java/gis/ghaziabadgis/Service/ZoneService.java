package gis.ghaziabadgis.Service;

import gis.ghaziabadgis.Entity.Zone;
import gis.ghaziabadgis.Repo.ZoneRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ZoneService {

    private final ZoneRepository zoneRepository;

    public ZoneService(ZoneRepository zoneRepository) {
        this.zoneRepository = zoneRepository;
    }

    public List<Zone> getAllZones() {
        return zoneRepository.findAll();
    }

    public Optional<Zone> getZoneByZoneNo(String zoneNo) {
        return zoneRepository.findByZoneNo(zoneNo);
    }


}

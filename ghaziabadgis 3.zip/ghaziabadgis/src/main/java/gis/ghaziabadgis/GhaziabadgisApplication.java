package gis.ghaziabadgis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GhaziabadgisApplication {

	public static void main(String[] args) {
		SpringApplication.run(GhaziabadgisApplication.class, args);
	}

}

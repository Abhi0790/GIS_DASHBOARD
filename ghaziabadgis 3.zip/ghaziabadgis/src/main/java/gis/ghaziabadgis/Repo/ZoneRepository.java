package gis.ghaziabadgis.Repo;

import gis.ghaziabadgis.Entity.Zone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ZoneRepository extends JpaRepository<Zone,Integer> {
    Optional<Zone> findByZoneNo(String zoneNo);



}

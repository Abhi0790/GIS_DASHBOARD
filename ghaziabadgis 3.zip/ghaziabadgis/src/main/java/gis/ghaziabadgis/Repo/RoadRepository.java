package gis.ghaziabadgis.Repo;

import gis.ghaziabadgis.Entity.Road;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RoadRepository extends JpaRepository<Road, Integer> {

    @Query("SELECT r FROM Road r WHERE r.wardNo = :wardNo")
    List<Road> findByWardNo(@Param("wardNo") String wardNo);

    @Query("SELECT r FROM Road r WHERE r.zoneNo = :zoneNo")
    List<Road> findByZoneNo(@Param("zoneNo") String zoneNo);

    @Query("SELECT r FROM Road r WHERE r.ownership = :ownership")
    List<Road> findByOwnership(@Param("ownership") String ownership);

    @Query("SELECT r FROM Road r WHERE r.condition = :condition")
    List<Road> findByCondition(@Param("condition") String condition);

    @Query(value = "SELECT COUNT(DISTINCT ward_name) FROM dummyq12 WHERE zone_no = :zoneNo", nativeQuery = true)
    int countDistinctWardsByZoneNo(@Param("zoneNo") String zoneNo);

    @Query(value = "SELECT COUNT(*) FROM dummyq12 WHERE ward_no = :wardNo", nativeQuery = true)
    int countRoadsByWardNo(@Param("wardNo") String wardNo);

    @Query("SELECT DISTINCT r.wardNo, r.wardName FROM Road r WHERE r.zoneNo = :zoneNo")
    List<Object[]> findDistinctWardsByZoneNo(@Param("zoneNo") String zoneNo);

    @Query(value = "SELECT * FROM dummyq12 WHERE ward_no LIKE '%,%'", nativeQuery = true)
    List<Road> findRoadsWithMultipleWards();

}

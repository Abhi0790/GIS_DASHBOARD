package gis.ghaziabadgis.Repo;

import gis.ghaziabadgis.Entity.MultiWardRoadSegment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MultiWardRoadSegmentRepository extends JpaRepository<MultiWardRoadSegment, Integer> {

    @Query("SELECT r FROM MultiWardRoadSegment r WHERE r.clippedWardNo = :wardNo")
    List<MultiWardRoadSegment> findByWardNo(String wardNo);

    @Query("SELECT r FROM MultiWardRoadSegment r WHERE LOWER(r.roadName) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<MultiWardRoadSegment> findByRoadName(String name);

    @Query(value = "SELECT * FROM multiward_roads WHERE clipped_ward_no = :wardNo", nativeQuery = true)
    List<MultiWardRoadSegment> findByClippedWardNo(@Param("wardNo") String wardNo);

}
